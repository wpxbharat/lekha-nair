// Created by iWeb 3.0.4 local-build-20121001

setTransparentGifURL('Media/transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWStrokeParts([{rect:new IWRect(-2,2,4,310),url:'Dance_files/stroke.png'},{rect:new IWRect(-2,-2,4,4),url:'Dance_files/stroke_1.png'},{rect:new IWRect(2,-2,412,4),url:'Dance_files/stroke_2.png'},{rect:new IWRect(414,-2,4,4),url:'Dance_files/stroke_3.png'},{rect:new IWRect(414,2,4,310),url:'Dance_files/stroke_4.png'},{rect:new IWRect(414,312,4,4),url:'Dance_files/stroke_5.png'},{rect:new IWRect(2,312,412,4),url:'Dance_files/stroke_6.png'},{rect:new IWRect(-2,312,4,4),url:'Dance_files/stroke_7.png'}],new IWSize(416,314)),shadow_0:new IWShadow({blurRadius:27,offset:new IWPoint(7.6249,11.7414),color:'#000000',opacity:0.500000}),shadow_1:new IWShadow({blurRadius:27,offset:new IWPoint(7.6249,11.7414),color:'#000000',opacity:0.500000})});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('Dance_files/DanceMoz.css')
adjustLineHeightIfTooBig('id1');adjustFontSizeIfTooBig('id1');adjustLineHeightIfTooBig('id2');adjustFontSizeIfTooBig('id2');adjustLineHeightIfTooBig('id3');adjustFontSizeIfTooBig('id3');adjustLineHeightIfTooBig('id4');adjustFontSizeIfTooBig('id4');detectBrowser();adjustLineHeightIfTooBig('id5');adjustFontSizeIfTooBig('id5');Widget.onload();applyEffects()}
function onPageUnload()
{Widget.onunload();}
